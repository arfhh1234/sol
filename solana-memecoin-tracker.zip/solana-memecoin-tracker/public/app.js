// Mobile Dashboard – reines Vanilla JS, kein Build-Step nötig (iPhone-freundlich
// direkt vom Server ausgeliefert). Einstellungen liegen in localStorage, weil
// diese Seite auf deinem eigenen Server läuft (kein Claude-Artifact-Sandbox-Limit).

const POLL_INTERVAL_MS = 5000;

const state = {
  apiBase: localStorage.getItem("apiBase") || window.location.origin,
  apiKey: localStorage.getItem("apiKey") || "",
  minLiquidity: Number(localStorage.getItem("minLiquidity") || 2000),
  minDevBuy: Number(localStorage.getItem("minDevBuy") || 0.5),
  botRunning: false,
  tokens: [],
};

const el = (id) => document.getElementById(id);

function authHeaders() {
  return { "Content-Type": "application/json", Authorization: `Bearer ${state.apiKey}` };
}

async function apiGet(path) {
  const res = await fetch(`${state.apiBase}${path}`);
  if (!res.ok) throw new Error(`GET ${path} → ${res.status}`);
  return res.json();
}

async function apiPost(path, body) {
  const res = await fetch(`${state.apiBase}${path}`, {
    method: "POST",
    headers: authHeaders(),
    body: JSON.stringify(body || {}),
  });
  if (!res.ok) {
    const err = await res.json().catch(() => ({}));
    throw new Error(err.error || `POST ${path} → ${res.status}`);
  }
  return res.json();
}

// ── Rendering ──
function renderTokens() {
  const list = el("tokenList");
  const empty = el("emptyState");
  el("tokenCount").textContent = state.tokens.length;

  if (state.tokens.length === 0) {
    if (!list.contains(empty)) list.appendChild(empty);
    empty.style.display = "block";
    return;
  }
  empty.style.display = "none";

  list.innerHTML = "";
  for (const entry of state.tokens) {
    const { token, analysis, updatedAt } = entry;
    const isFresh = Date.now() - new Date(updatedAt).getTime() < 60000;

    const card = document.createElement("div");
    card.className = "token-card";
    card.innerHTML = `
      <span class="status-dot status-${analysis.decision} ${isFresh ? "fresh" : ""}"></span>
      <div class="token-main">
        <div class="token-symbol">$${escapeHtml(token.symbol || "?")}</div>
        <div class="token-name">${escapeHtml(token.name || token.mintAddress)}</div>
        <span class="decision-pill decision-${analysis.decision}">${decisionLabel(analysis.decision)}</span>
      </div>
      <div class="token-scores">
        <div class="score-value">${analysis.score}</div>
        <div class="risk-value">Risk ${analysis.riskScore}</div>
      </div>
    `;
    card.addEventListener("click", () => openDetail(entry));
    list.appendChild(card);
  }
}

function decisionLabel(d) {
  return { BUY: "BUY", WATCH: "WATCH", AVOID: "AVOID", UNKNOWN: "UNKNOWN" }[d] || d;
}

function escapeHtml(str) {
  const d = document.createElement("div");
  d.textContent = str;
  return d.innerHTML;
}

function openDetail(entry) {
  const { token, analysis } = entry;
  el("detailContent").innerHTML = `
    <div class="detail-header">
      <span class="status-dot status-${analysis.decision}"></span>
      <span class="detail-symbol">$${escapeHtml(token.symbol || "?")}</span>
    </div>
    <div class="token-name">${escapeHtml(token.name || "")}</div>
    <div class="detail-scores">
      <div class="detail-score-box"><div class="label">Score</div><div class="value">${analysis.score}</div></div>
      <div class="detail-score-box"><div class="label">Risk</div><div class="value">${analysis.riskScore}</div></div>
    </div>
    <ul class="reasons-list">${analysis.reasons.map((r) => `<li>${escapeHtml(r)}</li>`).join("")}</ul>
    <div class="mint-row">${escapeHtml(token.mintAddress)}</div>
    <a class="explorer-link" href="https://solscan.io/token/${encodeURIComponent(token.mintAddress)}" target="_blank" rel="noopener">Auf Solscan öffnen ↗</a>
  `;
  openSheet("detailSheet", "detailBackdrop");
}

// ── Sheets ──
function openSheet(sheetId, backdropId) {
  el(sheetId).classList.add("open");
  el(backdropId).classList.add("open");
}
function closeSheet(sheetId, backdropId) {
  el(sheetId).classList.remove("open");
  el(backdropId).classList.remove("open");
}

el("settingsBtn").addEventListener("click", () => {
  el("apiBaseInput").value = state.apiBase;
  el("apiKeyInput").value = state.apiKey;
  el("minLiquidityInput").value = state.minLiquidity;
  el("minDevBuyInput").value = state.minDevBuy;
  openSheet("settingsSheet", "sheetBackdrop");
});
el("closeSettingsBtn").addEventListener("click", () => closeSheet("settingsSheet", "sheetBackdrop"));
el("sheetBackdrop").addEventListener("click", () => closeSheet("settingsSheet", "sheetBackdrop"));
el("closeDetailBtn").addEventListener("click", () => closeSheet("detailSheet", "detailBackdrop"));
el("detailBackdrop").addEventListener("click", () => closeSheet("detailSheet", "detailBackdrop"));

el("saveSettingsBtn").addEventListener("click", async () => {
  state.apiBase = el("apiBaseInput").value.trim().replace(/\/$/, "") || window.location.origin;
  state.apiKey = el("apiKeyInput").value.trim();
  state.minLiquidity = Number(el("minLiquidityInput").value) || 0;
  state.minDevBuy = Number(el("minDevBuyInput").value) || 0;

  localStorage.setItem("apiBase", state.apiBase);
  localStorage.setItem("apiKey", state.apiKey);
  localStorage.setItem("minLiquidity", state.minLiquidity);
  localStorage.setItem("minDevBuy", state.minDevBuy);

  try {
    await apiPost("/api/config", { minLiquidityUsd: state.minLiquidity, minDevBuySol: state.minDevBuy });
    el("statusHint").textContent = "Einstellungen gespeichert.";
  } catch (err) {
    el("statusHint").textContent = `Fehler: ${err.message}`;
  }
  closeSheet("settingsSheet", "sheetBackdrop");
});

// ── Start/Stop ──
el("toggleBotBtn").addEventListener("click", async () => {
  try {
    if (state.botRunning) {
      await apiPost("/api/control/stop");
    } else {
      await apiPost("/api/control/start");
    }
    await refreshHealth();
  } catch (err) {
    el("statusHint").textContent = `Fehler: ${err.message}`;
  }
});

function updateBotUI() {
  const btn = el("toggleBotBtn");
  const dot = el("liveDot");
  if (state.botRunning) {
    btn.classList.add("running");
    el("toggleBotLabel").textContent = "Bot stoppen";
    dot.classList.add("live");
    el("statusHint").textContent = "Live – hört auf neue pump.fun Launches";
  } else {
    btn.classList.remove("running");
    el("toggleBotLabel").textContent = "Bot starten";
    dot.classList.remove("live");
    el("statusHint").textContent = "Gestoppt";
  }
}

// ── Polling ──
async function refreshHealth() {
  const health = await apiGet("/api/health");
  state.botRunning = health.botRunning;
  updateBotUI();
}

async function refreshTokens() {
  state.tokens = await apiGet("/api/tokens");
  renderTokens();
}

async function pollLoop() {
  try {
    await Promise.all([refreshHealth(), refreshTokens()]);
  } catch (err) {
    el("statusHint").textContent = `Keine Verbindung zum Server (${err.message})`;
  }
  setTimeout(pollLoop, POLL_INTERVAL_MS);
}

if ("serviceWorker" in navigator) {
  navigator.serviceWorker.register("sw.js").catch(() => {});
}

pollLoop();
