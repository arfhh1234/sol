// Minimaler Service Worker – nötig, damit iOS die Seite als installierbare
// PWA erkennt. Cached bewusst nichts Aggressives, da die Live-Daten über
// /api/* immer frisch vom Server kommen sollen.
self.addEventListener("install", (event) => {
  self.skipWaiting();
});

self.addEventListener("activate", (event) => {
  self.clients.claim();
});

self.addEventListener("fetch", () => {
  // Pass-through: kein Caching der API-Calls, damit das Dashboard nie
  // veraltete Token-Daten anzeigt.
});
