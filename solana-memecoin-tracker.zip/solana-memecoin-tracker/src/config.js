import "dotenv/config";

/**
 * Zentrale Konfiguration.
 * `runtime` enthält Werte, die sich über die Mobile-Dashboard-API zur
 * Laufzeit ändern lassen (Risk Settings, Bot Start/Stop) – siehe
 * src/api/server.js (POST /api/config, POST /api/control/*).
 */
export const config = {
  port: Number(process.env.PORT || 3000),

  solanaRpcUrl: process.env.SOLANA_RPC_URL || "https://api.mainnet-beta.solana.com",
  pumpPortalApiKey: process.env.PUMPPORTAL_API_KEY || "",
  discordWebhookUrl: process.env.DISCORD_WEBHOOK_URL || "",
  dashboardPublicUrl: process.env.DASHBOARD_PUBLIC_URL || "http://localhost:3000",
  dashboardApiKey: process.env.DASHBOARD_API_KEY || "",

  // Bekannte Solana-Programm-/Systemadressen, die die Risk-Engine kennen muss
  addresses: {
    // Kanonische "Dead"-Adresse. Tokens, die hierher gesendet wurden, sind
    // für niemanden mehr zugreifbar (auch wenn sie technisch keinen
    // Burn-Instruction-Aufruf darstellen – für Rug-Zwecke zählt "unzugreifbar").
    incinerator: "1nc1nerator11111111111111111111111111111111",
  },

  // Laufzeit-veränderbare Risk-Engine-Einstellungen (Startwerte aus .env)
  runtime: {
    botRunning: false,
    minLiquidityUsd: Number(process.env.MIN_LIQUIDITY_USD || 2000),
    minDevBuySol: Number(process.env.MIN_DEV_BUY_SOL || 0.5),
    riskWeights: {
      mintAuthorityActive: 35,
      freezeAuthorityActive: 20,
      liquidityNotSecured: 30,
      topHolderConcentration: 15,
      lowLiquidity: 10,
    },
    decisionThresholds: {
      avoid: 55, // riskScore >= 55  -> AVOID / POSSIBLE RUG
      watch: 30, // riskScore >= 30  -> WATCH / HIGH RISK
      // riskScore < 30              -> BUY / POTENTIAL BUY
    },
    watchedWallets: [], // "Smart Money" Wallets – Phase 4, hier schon vorbereitet
  },
};

export function assertRequiredConfig() {
  const missing = [];
  if (!config.discordWebhookUrl) missing.push("DISCORD_WEBHOOK_URL");
  if (missing.length) {
    console.warn(
      `⚠️  Fehlende .env Werte: ${missing.join(", ")}. Discord-Alerts sind deaktiviert, bis das gesetzt ist.`
    );
  }
}
