import WebSocket from "ws";
import { config } from "../config.js";

const PUMPPORTAL_URL = "wss://pumpportal.fun/api/data";
const RECONNECT_DELAY_MS = 5000;

/**
 * Verbindet sich mit dem PumpPortal-WebSocket und abonniert neue
 * Token-Launches auf pump.fun ("subscribeNewToken" – laut PumpPortal-Doku
 * aktuell kostenlos, kein Wallet nötig). Läuft dauerhaft mit
 * Auto-Reconnect, solange `isRunning()` true zurückgibt.
 *
 * WICHTIG: pump.fun launcht mehrere tausend Tokens/Tag. Ohne Filter würde
 * das sofort jeden Discord-Kanal fluten – siehe onNewToken-Filter unten
 * bzw. MIN_DEV_BUY_SOL in der Config.
 *
 * @param {(token: object) => void} onNewToken - Callback pro neuem Token
 * @param {() => boolean} isRunning - wird vor jedem (Re-)Connect geprüft
 */
export function startPumpPortalListener(onNewToken, isRunning) {
  let ws = null;
  let stoppedManually = false;

  function connect() {
    if (!isRunning() || stoppedManually) return;

    const url = config.pumpPortalApiKey
      ? `${PUMPPORTAL_URL}?api-key=${config.pumpPortalApiKey}`
      : PUMPPORTAL_URL;

    ws = new WebSocket(url);

    ws.on("open", () => {
      console.log("📡 PumpPortal verbunden – abonniere neue Token-Launches");
      ws.send(JSON.stringify({ method: "subscribeNewToken" }));
    });

    ws.on("message", (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        // PumpPortal schickt bei subscribeNewToken u.a.: mint, name, symbol,
        // traderPublicKey (Dev-Wallet), initialBuy, marketCapSol, uri
        if (msg && msg.mint) {
          const initialBuySol = Number(msg.solAmount ?? msg.initialBuy ?? 0);
          if (initialBuySol < config.runtime.minDevBuySol) return; // Rausch-Filter

          onNewToken({
            mintAddress: msg.mint,
            name: msg.name,
            symbol: msg.symbol,
            devWallet: msg.traderPublicKey,
            initialBuySol,
            source: "pumpfun",
            discoveredAt: new Date().toISOString(),
          });
        }
      } catch (err) {
        console.error("PumpPortal: Nachricht konnte nicht geparst werden", err.message);
      }
    });

    ws.on("close", () => {
      console.log("📡 PumpPortal-Verbindung getrennt");
      if (isRunning() && !stoppedManually) {
        setTimeout(connect, RECONNECT_DELAY_MS);
      }
    });

    ws.on("error", (err) => {
      console.error("PumpPortal WebSocket-Fehler:", err.message);
    });
  }

  connect();

  return function stop() {
    stoppedManually = true;
    if (ws) ws.close();
  };
}
