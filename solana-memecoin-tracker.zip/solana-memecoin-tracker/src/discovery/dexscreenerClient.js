const BASE_URL = "https://api.dexscreener.com";

/**
 * Reichert einen Token mit Pool-/Liquiditätsdaten von DexScreener an.
 * Kostenlos, kein API-Key nötig (Stand aktueller Doku), aber rate-limitiert
 * (~300 req/min auf den Pairs-Endpunkten) und NICHT in Echtzeit – der
 * DexScreener-Indexer hinkt frischen On-Chain-Events um Sekunden bis
 * Minuten hinterher. Für die erste Sekunde nach einem pump.fun-Launch ist
 * PumpPortal (siehe pumpPortalListener.js) die schnellere Quelle; DexScreener
 * eignet sich hier vor allem, sobald ein Token einen echten DEX-Pool hat
 * (z.B. nach der pump.fun-Graduation zu Raydium).
 *
 * @param {string} mintAddress
 * @returns {Promise<object|null>} { liquidityUsd, lpMintAddress, priceUsd, pairUrl } oder null
 */
export async function fetchDexScreenerData(mintAddress) {
  const res = await fetch(`${BASE_URL}/latest/dex/tokens/${mintAddress}`);
  if (!res.ok) {
    throw new Error(`DexScreener antwortete mit Status ${res.status}`);
  }
  const data = await res.json();
  const pairs = data?.pairs?.filter((p) => p.chainId === "solana") || [];
  if (pairs.length === 0) return null;

  // Pool mit der höchsten Liquidität nehmen, falls mehrere existieren
  const best = pairs.sort((a, b) => (b.liquidity?.usd || 0) - (a.liquidity?.usd || 0))[0];

  return {
    liquidityUsd: best.liquidity?.usd ?? null,
    // Hinweis: DexScreener liefert die Pool-Adresse (pairAddress), nicht
    // direkt die LP-Token-Mint-Adresse. Für den Liquidity-Lock-Check in
    // rugCheck.js braucht es die LP-Mint – je nach DEX (Raydium/Meteora/…)
    // muss die aus der Pool-Adresse abgeleitet werden. Das ist als
    // Erweiterungspunkt markiert (Phase 2), da sich das je nach AMM
    // unterscheidet und hier ohne Live-Zugriff nicht verlässlich zu bauen ist.
    pairAddress: best.pairAddress,
    priceUsd: best.priceUsd ? Number(best.priceUsd) : null,
    pairUrl: best.url,
    dexId: best.dexId,
  };
}
