import { config, assertRequiredConfig } from "./config.js";
import { createServer } from "./api/server.js";
import { startPumpPortalListener } from "./discovery/pumpPortalListener.js";
import { fetchDexScreenerData } from "./discovery/dexscreenerClient.js";
import { analyzeToken, DECISION_META } from "./solana/rugCheck.js";
import { sendDiscordAlert } from "./discord/alerts.js";
import { upsertToken, recordAlert } from "./store/tokenStore.js";

assertRequiredConfig();

let stopListener = null;

async function handleNewToken(token) {
  console.log(`🆕 Neuer Token entdeckt: $${token.symbol} (${token.mintAddress})`);

  // Kurze Pause, damit der Pool überhaupt erst indexiert werden kann,
  // bevor wir Liquiditätsdaten abfragen (DexScreener hinkt frischen
  // Launches etwas hinterher, siehe dexscreenerClient.js).
  let enrichment = null;
  try {
    await new Promise((r) => setTimeout(r, 3000));
    enrichment = await fetchDexScreenerData(token.mintAddress);
  } catch (err) {
    console.warn(`DexScreener-Enrichment fehlgeschlagen für $${token.symbol}:`, err.message);
  }

  let analysis;
  try {
    analysis = await analyzeToken({
      mintAddress: token.mintAddress,
      lpMintAddress: null, // siehe TODO in dexscreenerClient.js (Phase 2)
      liquidityUsd: enrichment?.liquidityUsd ?? null,
    });
  } catch (err) {
    console.error(`Analyse fehlgeschlagen für $${token.symbol}:`, err.message);
    return;
  }

  const meta = DECISION_META[analysis.decision];
  console.log(`   → ${meta.emoji} ${meta.label} | Score ${analysis.score} | Risk ${analysis.riskScore}`);

  upsertToken(token, analysis);
  recordAlert(token, analysis);

  try {
    await sendDiscordAlert(token, analysis);
  } catch (err) {
    console.error("Discord-Alert fehlgeschlagen:", err.message);
  }
}

function startBot() {
  if (config.runtime.botRunning) return;
  config.runtime.botRunning = true;
  console.log("▶️  Bot gestartet – höre auf neue pump.fun Launches …");
  stopListener = startPumpPortalListener(handleNewToken, () => config.runtime.botRunning);
}

function stopBot() {
  if (!config.runtime.botRunning) return;
  config.runtime.botRunning = false;
  console.log("⏸️  Bot gestoppt");
  if (stopListener) stopListener();
  stopListener = null;
}

const app = createServer({ startBot, stopBot });

app.listen(config.port, () => {
  console.log(`📱 Mobile Dashboard läuft auf http://localhost:${config.port}`);
  console.log(`   Vom iPhone erreichbar über: ${config.dashboardPublicUrl}`);
  console.log(`   Bot ist noch NICHT gestartet – im Dashboard auf "Start" tippen,`);
  console.log(`   oder POST ${config.dashboardPublicUrl}/api/control/start aufrufen.`);
});
