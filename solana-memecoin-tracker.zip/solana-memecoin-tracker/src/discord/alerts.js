import { config } from "../config.js";
import { DECISION_META } from "../solana/rugCheck.js";

const COLOR_HEX = {
  BUY: "3DDC84",
  WATCH: "E8C547",
  AVOID: "FF5C5C",
  UNKNOWN: "6B7280",
};

/**
 * Schickt einen mobil-optimierten Discord-Alert (kurz, klar, mit Emojis/
 * Farben) über den konfigurierten Webhook. Discords eigene iPhone-App
 * übernimmt die Push-Notification – dafür ist keine eigene Push-
 * Infrastruktur nötig.
 *
 * @param {object} token - { name, symbol, mintAddress }
 * @param {object} analysis - Ergebnis von rugCheck.analyzeToken()
 */
export async function sendDiscordAlert(token, analysis) {
  if (!config.discordWebhookUrl) {
    console.log(`(Discord-Webhook nicht gesetzt, Alert übersprungen für $${token.symbol})`);
    return;
  }

  const meta = DECISION_META[analysis.decision];
  const dashboardLink = `${config.dashboardPublicUrl}/#/token/${token.mintAddress}`;

  // Nur die wichtigsten 3-4 Gründe zeigen – am Handy muss es kurz bleiben
  const topReasons = analysis.reasons.slice(0, 4).join("\n");

  const embed = {
    title: `${meta.emoji} $${token.symbol || "?"} — ${meta.label}`,
    description: `**Score:** ${analysis.score}  |  **Risk:** ${analysis.riskScore}\n\n${topReasons}`,
    color: parseInt(COLOR_HEX[analysis.decision], 16),
    url: dashboardLink,
    fields: [
      { name: "Mint", value: `\`${token.mintAddress}\``, inline: false },
      { name: "Quelle", value: token.source || "unbekannt", inline: true },
    ],
    footer: { text: "Solana Memecoin Tracker · Öffne den Link für die volle Analyse" },
    timestamp: analysis.analyzedAt,
  };

  const res = await fetch(config.discordWebhookUrl, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ embeds: [embed] }),
  });

  if (!res.ok) {
    console.error(`Discord-Alert fehlgeschlagen: ${res.status} ${await res.text()}`);
  }
}
