import { config } from "../config.js";
import { fetchMintInfo, fetchHolderConcentration, fetchLiquidityLockStatus } from "./tokenData.js";

/**
 * Kombiniert die einzelnen On-Chain-Checks zu einem Risk-Score (0-100) und
 * einer finalen Entscheidung. Das ist eine heuristische Einschätzung
 * öffentlicher On-Chain-Daten – KEINE Garantie und KEINE Anlageberatung.
 * Auch Tokens mit "gutem" Score können durch Dinge scammen, die diese
 * Checks nicht erfassen (Social Engineering, Fake-Volume, etc.).
 *
 * @param {object} token - { mintAddress, lpMintAddress?, liquidityUsd? }
 * @returns {Promise<object>} vollständige Analyse inkl. Score/Entscheidung
 */
export async function analyzeToken(token) {
  const { mintAddress, lpMintAddress, liquidityUsd } = token;
  const weights = config.runtime.riskWeights;
  const reasons = [];
  let riskScore = 0;
  let dataComplete = true;

  // 1. Mint- & Freeze-Authority
  let mintInfo = null;
  try {
    mintInfo = await fetchMintInfo(mintAddress);
    if (mintInfo.mintAuthorityActive) {
      riskScore += weights.mintAuthorityActive;
      reasons.push("⚠️ Mint Authority aktiv – Dev kann unbegrenzt neue Tokens erzeugen");
    } else {
      reasons.push("✅ Mint Authority deaktiviert");
    }
    if (mintInfo.freezeAuthorityActive) {
      riskScore += weights.freezeAuthorityActive;
      reasons.push("⚠️ Freeze Authority aktiv – Dev kann Wallets einfrieren");
    } else {
      reasons.push("✅ Freeze Authority deaktiviert");
    }
  } catch (err) {
    dataComplete = false;
    reasons.push("⚫ Mint-Daten konnten nicht geladen werden");
  }

  // 2. Liquidität gesichert (verbrannt / incinerator)?
  if (lpMintAddress) {
    try {
      const lock = await fetchLiquidityLockStatus(lpMintAddress);
      if (lock.secured) {
        reasons.push(`✅ Liquidität gesichert (${lock.method}, ${lock.securedPercent.toFixed(1)}%)`);
      } else {
        riskScore += weights.liquidityNotSecured;
        reasons.push("⚠️ Liquidität NICHT nachweislich gesichert – Dev könnte LP abziehen");
      }
    } catch (err) {
      reasons.push("⚫ LP-Lock-Status konnte nicht geprüft werden");
    }
  } else {
    reasons.push("⚫ Keine LP-Mint-Adresse übergeben – Liquiditäts-Check übersprungen");
  }

  // 3. Holder-Konzentration
  try {
    const excl = lpMintAddress ? [lpMintAddress] : [];
    const { top10Percent, holderCount } = await fetchHolderConcentration(mintAddress, excl);
    if (top10Percent > 50) {
      riskScore += weights.topHolderConcentration;
      reasons.push(`⚠️ Top-10-Halter besitzen ${top10Percent.toFixed(1)}% des Supplys`);
    } else {
      reasons.push(`✅ Holder-Verteilung ok (Top 10: ${top10Percent.toFixed(1)}%, ${holderCount} Halter)`);
    }
  } catch (err) {
    reasons.push("⚫ Holder-Verteilung konnte nicht geladen werden");
  }

  // 4. Liquiditäts-Höhe (aus DexScreener o.ä. übergeben, siehe discovery/dexscreenerClient.js)
  if (typeof liquidityUsd === "number") {
    if (liquidityUsd < config.runtime.minLiquidityUsd) {
      riskScore += weights.lowLiquidity;
      reasons.push(`⚠️ Liquidität niedrig ($${liquidityUsd.toLocaleString("de-DE")})`);
    } else {
      reasons.push(`✅ Liquidität: $${liquidityUsd.toLocaleString("de-DE")}`);
    }
  }

  riskScore = Math.min(100, riskScore);
  const score = 100 - riskScore; // "Score" = Gegenteil von Risk, wie im Alert-Format gewünscht

  let decision = "UNKNOWN";
  if (!dataComplete) {
    decision = "UNKNOWN";
  } else if (riskScore >= config.runtime.decisionThresholds.avoid) {
    decision = "AVOID";
  } else if (riskScore >= config.runtime.decisionThresholds.watch) {
    decision = "WATCH";
  } else {
    decision = "BUY";
  }

  return {
    mintAddress,
    score,
    riskScore,
    decision, // "BUY" | "WATCH" | "AVOID" | "UNKNOWN"
    reasons,
    dataComplete,
    analyzedAt: new Date().toISOString(),
  };
}

export const DECISION_META = {
  BUY: { emoji: "🟢", label: "BUY / POTENTIAL BUY" },
  WATCH: { emoji: "🟡", label: "WATCH / HIGH RISK" },
  AVOID: { emoji: "🔴", label: "AVOID / POSSIBLE RUG" },
  UNKNOWN: { emoji: "⚫", label: "UNKNOWN / INSUFFICIENT DATA" },
};
