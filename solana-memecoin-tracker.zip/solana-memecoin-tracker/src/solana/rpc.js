import { Connection } from "@solana/web3.js";
import { config } from "../config.js";

let connection = null;

/**
 * Liefert eine einzige geteilte Solana-Connection für den ganzen Prozess.
 * Mit dem öffentlichen RPC (Default) bist du stark rate-limitiert –
 * für echten Betrieb einen Provider wie Helius (kostenloser Tier reicht
 * zum Start) in SOLANA_RPC_URL eintragen.
 */
export function getConnection() {
  if (!connection) {
    connection = new Connection(config.solanaRpcUrl, "confirmed");
  }
  return connection;
}
