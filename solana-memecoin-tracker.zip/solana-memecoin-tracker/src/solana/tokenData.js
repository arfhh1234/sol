import { PublicKey } from "@solana/web3.js";
import { getMint } from "@solana/spl-token";
import { getConnection } from "./rpc.js";
import { config } from "../config.js";

/**
 * Holt die Mint-Account-Daten eines Tokens.
 * mintAuthority === null  -> Minting wurde deaktiviert (gut, kein unendliches Nachprägen mehr möglich)
 * freezeAuthority === null -> Freeze wurde deaktiviert (gut, Dev kann Holder-Wallets nicht einfrieren)
 * Launchpads wie pump.fun setzen beide Werte bei Erstellung standardmäßig auf null.
 */
export async function fetchMintInfo(mintAddress) {
  const connection = getConnection();
  const mintPubkey = new PublicKey(mintAddress);
  const mint = await getMint(connection, mintPubkey);

  return {
    address: mintAddress,
    supply: mint.supply, // BigInt, in kleinster Einheit (siehe decimals)
    decimals: mint.decimals,
    mintAuthorityActive: mint.mintAuthority !== null,
    freezeAuthorityActive: mint.freezeAuthority !== null,
  };
}

/**
 * Holt die größten Halter eines Mints (max. 20, RPC-Limit) und berechnet,
 * wie viel Prozent der Top-10-Halter (ohne den LP-Pool selbst) am
 * Gesamtsupply halten. Hohe Konzentration = höheres Risiko für Dumps.
 *
 * @param {string} mintAddress
 * @param {string[]} excludeAddresses - z.B. die LP-Pool-Adresse, die man
 *   aus der "Holder-Konzentration" rausrechnen will
 */
export async function fetchHolderConcentration(mintAddress, excludeAddresses = []) {
  const connection = getConnection();
  const mintPubkey = new PublicKey(mintAddress);
  const largest = await connection.getTokenLargestAccounts(mintPubkey);

  const exclude = new Set(excludeAddresses);
  const accounts = largest.value.filter((a) => !exclude.has(a.address.toBase58()));

  const totalSupply = largest.value.reduce((sum, a) => sum + BigInt(a.amount), 0n);
  if (totalSupply === 0n) {
    return { top10Percent: 0, holderCount: accounts.length };
  }

  const top10 = accounts.slice(0, 10).reduce((sum, a) => sum + BigInt(a.amount), 0n);
  const top10Percent = Number((top10 * 10000n) / totalSupply) / 100; // 2 Nachkommastellen

  return { top10Percent, holderCount: accounts.length };
}

/**
 * Prüft, ob die LP-Tokens eines Pools "gesichert" sind, also entweder an
 * die bekannte Incinerator-Adresse gesendet (praktisch unzugreifbar) oder
 * per echtem Burn-Instruction verbrannt wurden (führt zu supply-Reduktion).
 *
 * Wichtig: Locker-Programme (z.B. Streamflow, Team Finance) werden hier
 * NICHT automatisch erkannt, da sich Programm-Adressen ändern können und
 * eine falsche Zuordnung schlimmer wäre als "unbekannt". Das ist ein
 * bewusster Erweiterungspunkt für Phase 2.
 *
 * @param {string} lpMintAddress - Mint-Adresse des LP-Tokens des Pools
 */
export async function fetchLiquidityLockStatus(lpMintAddress) {
  const connection = getConnection();
  const lpMintPubkey = new PublicKey(lpMintAddress);

  const [mintInfo, largest] = await Promise.all([
    getMint(connection, lpMintPubkey),
    connection.getTokenLargestAccounts(lpMintPubkey),
  ]);

  if (mintInfo.supply === 0n) {
    // Supply 0 heißt: alle LP-Tokens wurden per echtem Burn vernichtet -> maximal sicher
    return { secured: true, method: "burned", securedPercent: 100 };
  }

  const topHolder = largest.value[0];
  if (!topHolder) {
    return { secured: false, method: "unknown", securedPercent: 0 };
  }

  const isIncinerator = topHolder.address.toBase58() === config.addresses.incinerator;
  const securedPercent =
    Number((BigInt(topHolder.amount) * 10000n) / mintInfo.supply) / 100;

  return {
    secured: isIncinerator && securedPercent > 90,
    method: isIncinerator ? "incinerator" : "held_by_wallet",
    securedPercent: isIncinerator ? securedPercent : 0,
    topHolderAddress: topHolder.address.toBase58(),
  };
}
