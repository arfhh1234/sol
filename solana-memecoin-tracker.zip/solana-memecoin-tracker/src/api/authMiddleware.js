import { config } from "../config.js";

/**
 * Einfacher Bearer-Token-Schutz für alle Endpunkte, die Zustand ändern
 * (Bot starten/stoppen, Risk-Settings, Wallets). Das Dashboard fragt den
 * Key einmal ab (siehe public/app.js) und speichert ihn lokal im Browser.
 * Reicht für "nur ich vom iPhone" – für mehrere Nutzer bräuchte es echte
 * Accounts, das ist hier bewusst nicht Teil von Phase 1.
 */
export function requireApiKey(req, res, next) {
  if (!config.dashboardApiKey) {
    return res.status(500).json({ error: "DASHBOARD_API_KEY ist nicht konfiguriert (.env prüfen)" });
  }
  const provided = req.headers.authorization?.replace(/^Bearer\s+/i, "");
  if (provided !== config.dashboardApiKey) {
    return res.status(401).json({ error: "Ungültiger oder fehlender API-Key" });
  }
  next();
}
