import express from "express";
import path from "node:path";
import { fileURLToPath } from "node:url";
import { config } from "../config.js";
import { requireApiKey } from "./authMiddleware.js";
import { listTokens, getToken, listAlerts } from "../store/tokenStore.js";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PUBLIC_DIR = path.join(__dirname, "../../public");

/**
 * @param {{ startBot: () => void, stopBot: () => void }} botControls
 *   Callbacks, mit denen die Control-Endpunkte den Discovery-Loop aus
 *   src/index.js steuern.
 */
export function createServer(botControls) {
  const app = express();
  app.use(express.json());
  app.use(express.static(PUBLIC_DIR));

  // ── Read-Endpunkte: kein Auth nötig, nur lesend ──
  app.get("/api/health", (req, res) => {
    res.json({ ok: true, botRunning: config.runtime.botRunning });
  });

  app.get("/api/tokens", (req, res) => {
    res.json(listTokens({ limit: Number(req.query.limit) || 50 }));
  });

  app.get("/api/tokens/:mint", (req, res) => {
    const entry = getToken(req.params.mint);
    if (!entry) return res.status(404).json({ error: "Token nicht gefunden" });
    res.json(entry);
  });

  app.get("/api/alerts", (req, res) => {
    res.json(listAlerts({ limit: Number(req.query.limit) || 50 }));
  });

  app.get("/api/config", (req, res) => {
    // riskWeights/thresholds sind bewusst öffentlich lesbar (keine Secrets),
    // nur das Ändern erfordert unten den API-Key
    res.json(config.runtime);
  });

  // ── Write-Endpunkte: erfordern den Dashboard-API-Key ──
  app.post("/api/control/start", requireApiKey, (req, res) => {
    botControls.startBot();
    res.json({ ok: true, botRunning: true });
  });

  app.post("/api/control/stop", requireApiKey, (req, res) => {
    botControls.stopBot();
    res.json({ ok: true, botRunning: false });
  });

  app.post("/api/config", requireApiKey, (req, res) => {
    const { minLiquidityUsd, minDevBuySol, riskWeights, decisionThresholds } = req.body || {};
    if (typeof minLiquidityUsd === "number") config.runtime.minLiquidityUsd = minLiquidityUsd;
    if (typeof minDevBuySol === "number") config.runtime.minDevBuySol = minDevBuySol;
    if (riskWeights) Object.assign(config.runtime.riskWeights, riskWeights);
    if (decisionThresholds) Object.assign(config.runtime.decisionThresholds, decisionThresholds);
    res.json({ ok: true, runtime: config.runtime });
  });

  app.post("/api/wallets", requireApiKey, (req, res) => {
    // Vorbereitet für Phase 4 (Smart-Money-Tracking) – speichert Wallets
    // schon mal, ausgewertet werden sie aktuell noch nicht.
    const { address, label } = req.body || {};
    if (!address) return res.status(400).json({ error: "address fehlt" });
    config.runtime.watchedWallets.push({ address, label: label || "", addedAt: new Date().toISOString() });
    res.json({ ok: true, watchedWallets: config.runtime.watchedWallets });
  });

  return app;
}
