# Solana Memecoin Tracker — Phase 1

Mobile-first Discovery- & Rug-Risk-Tool für neue Solana-Memecoins, steuerbar
vom iPhone über ein PWA-Dashboard + Discord-Alerts als Push-Kanal.

Dies ist **Phase 1** aus deiner Roadmap: Mobile Architektur, Solana Data
Layer, Discord Mobile Alert System, Token Discovery Engine. Smart-Money-
Tracking, Bundle/Sniper-Detection, Social-Hype-Analyse und Backtesting
(Phasen 4+) sind vorbereitet (Datenstrukturen, Endpunkte), aber bewusst noch
nicht implementiert — dazu unten mehr.

## Was das System tut

1. **Discovery**: hört über [PumpPortal](https://pumpportal.fun/data-api/real-time/)
   (kostenloser WebSocket) live auf neue Token-Launches auf pump.fun.
2. **Analyse**: prüft pro Token On-Chain-Daten direkt via Solana RPC —
   Mint Authority, Freeze Authority, Liquiditäts-Sicherung, Holder-
   Konzentration — und reichert das mit Liquiditätsdaten von DexScreener an.
3. **Scoring**: kombiniert die Checks zu einem Score/Risk-Wert und einer
   Entscheidung: 🟢 BUY / 🟡 WATCH / 🔴 AVOID / ⚫ UNKNOWN.
4. **Alert**: schickt einen kompakten, mobil-optimierten Discord-Alert mit
   Link zum Dashboard. Discords eigene App übernimmt die Push-Notification
   aufs iPhone.
5. **Dashboard**: zeigt alle getrackten Tokens live, lässt dich den Bot
   starten/stoppen und Risk-Settings ändern — als installierbare PWA.

## Wichtiger Hinweis

Das ist ein **heuristisches Risiko-Tool auf Basis öffentlicher On-Chain-
Daten**, keine Anlageberatung und keine Garantie. Ein "BUY"-Score bedeutet
nur "in diesen konkreten Checks nichts Auffälliges gefunden" — nicht "sicher".
Memecoins, gerade brandneue, sind hochspekulativ und ein großer Teil davon
sind Scams. Die Scores/Schwellwerte in `src/config.js` sind Startwerte, die
du an dein eigenes Risikoempfinden anpassen solltest.

## Setup

```bash
npm install
cp .env.example .env
```

Dann `.env` ausfüllen:

- **SOLANA_RPC_URL**: Der öffentliche Solana-RPC reicht nur zum Testen
  (stark rate-limitiert). Empfehlung: kostenloser Account bei
  [helius.dev](https://helius.dev) (1 Mio. Credits/Monat gratis) → RPC-URL
  eintragen.
- **DISCORD_WEBHOOK_URL**: In deinem Discord-Server → Kanal-Einstellungen →
  Integrationen → Webhooks → "Neuer Webhook" → URL kopieren.
- **DASHBOARD_API_KEY**: Ein selbst ausgedachtes, langes Passwort — schützt
  die Start/Stop/Settings-Endpunkte, damit nicht jeder mit deiner URL deinen
  Bot fernsteuern kann.
- **PUMPPORTAL_API_KEY**: Für den reinen "neue Tokens"-Stream laut
  PumpPortal-Doku aktuell nicht zwingend nötig, kann leer bleiben.

Lokal starten:

```bash
npm run dev
```

Dashboard öffnet sich unter `http://localhost:3000`. Der Bot läuft **nicht**
automatisch los — im Dashboard oben auf "Bot starten" tippen (oder
`POST /api/control/start` mit `Authorization: Bearer <DASHBOARD_API_KEY>`).

## Vom iPhone aus nutzen

Damit dein iPhone das Dashboard erreicht, muss der Server öffentlich
erreichbar sein (nicht nur `localhost` auf deinem Rechner). Einfachste
Optionen für einen 24/7-Betrieb:

- **Railway** oder **Render** — Node-Projekt per Git-Push deployen, beide
  haben kostenlose/günstige Einstiegs-Tiers.
- **Hetzner Cloud** (oder jeder andere VPS) — etwas mehr Setup, dafür volle
  Kontrolle, ca. 4-5€/Monat für die kleinste Instanz.

Nach dem Deployment: `DASHBOARD_PUBLIC_URL` in `.env` auf deine echte URL
setzen (wird für die Links in den Discord-Alerts gebraucht), dann im
Dashboard unter ⚙️ Einstellungen die gleiche URL + deinen API-Key eintragen.
Danach über Safari → Teilen → "Zum Home-Bildschirm" als PWA installieren.

## Projektstruktur

```
src/
  config.js                    Zentrale Konfiguration + Laufzeit-Settings
  solana/
    rpc.js                     Solana-Connection
    tokenData.js                Mint-Info, Holder-Verteilung, LP-Lock-Status
    rugCheck.js                 Scoring-Engine (Score/Risk/Decision)
  discovery/
    pumpPortalListener.js       WebSocket: neue pump.fun Launches
    dexscreenerClient.js        Liquiditäts-Enrichment
  discord/
    alerts.js                   Mobile-optimierte Discord-Alerts
  store/
    tokenStore.js                In-Memory Store (Tokens + Alert-Verlauf)
  api/
    server.js                    Express-REST-API fürs Dashboard
    authMiddleware.js             Schützt Control-Endpunkte
  index.js                       Verbindet alles
public/                          Mobile Dashboard (PWA, Vanilla JS)
```

## Bekannte Grenzen von Phase 1 (ehrlich, nicht versteckt)

- **LP-Lock-Check läuft nur, wenn eine LP-Mint-Adresse übergeben wird.**
  DexScreener liefert die Pool-Adresse, nicht direkt die LP-Token-Mint — die
  Ableitung unterscheidet sich je nach AMM (Raydium/Meteora/PumpSwap). Das
  ist als TODO in `dexscreenerClient.js` markiert und ein guter nächster
  Schritt für Phase 2.
- **Locker-Programme** (Streamflow, Team Finance, etc.) werden aktuell nicht
  erkannt — nur "verbrannt/incinerator" zählt als gesichert. Alles andere
  landet konservativ als "nicht nachweislich gesichert", auch wenn es in
  Wirklichkeit gelockt sein könnte.
- **DexScreener hinkt frischen On-Chain-Events Sekunden bis Minuten
  hinterher** — für die allererste Sekunde nach Launch ist PumpPortal die
  schnellere Quelle, DexScreener dient hier vor allem der Anreicherung.
- **Kein Trading.** Bewusst nur Discovery + Analyse + Alert. Trading-
  Integration ist laut deiner Vorgabe "manuell bestätigt" — das ist als
  eigene, spätere Phase zu bauen, nicht Teil dieses Scaffolds.
- Ich konnte den Code in dieser Umgebung nicht gegen die echten Live-APIs
  testen (kein Netzwerkzugriff im Sandbox) — die Endpunkte/Formate sind
  gegen aktuelle Doku recherchiert, aber prüf beim ersten Lauf die
  Server-Logs, falls sich an einer API kurzfristig etwas geändert hat.

## Nächste Schritte (Phase 2+, aus deiner Roadmap)

- Wallet-Tracking / Smart Money (Endpunkt `POST /api/wallets` existiert
  schon, Auswertung fehlt noch)
- Bundle-/Sniper-/Insider-Erkennung (Transaktions-Cluster-Analyse)
- Social-Hype-Signal (X/TikTok)
- Backtesting-Modul
- LP-Mint-Ableitung je AMM (siehe oben) + Locker-Programm-Erkennung

Sag Bescheid, mit welchem davon ich als Nächstes weitermachen soll.
